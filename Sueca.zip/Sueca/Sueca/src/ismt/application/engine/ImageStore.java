package ismt.application.engine;

import java.util.HashMap;

import javafx.scene.image.Image;

public class ImageStore
{
	   public static Image card_back_image ;
	   public static HashMap<String, Image> card_face_images ;
}